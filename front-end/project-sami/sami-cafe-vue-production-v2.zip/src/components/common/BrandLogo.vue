<template><div class="brand-logo"><img src="/logo.png" alt="شعار عناية سامي"><span><b>مقهى عناية سامي</b><small>SAMI CAFE</small></span></div></template>
