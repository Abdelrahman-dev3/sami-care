<script setup>import ToastMessage from '@/components/common/ToastMessage.vue'</script>
<template><main class="app"><RouterView/></main><ToastMessage/></template>
