<script setup>
import { ref } from 'vue'
import AboutSection from './components/AboutSection.vue'
import BranchesSection from './components/BranchesSection.vue'
import ContactSection from './components/ContactSection.vue'
import FeaturesSection from './components/FeaturesSection.vue'
import HeroSection from './components/HeroSection.vue'
import PageActions from './components/PageActions.vue'
import QuickActions from './components/QuickActions.vue'
import ServicesSection from './components/ServicesSection.vue'
import SiteFooter from './components/SiteFooter.vue'
import StickyActions from './components/StickyActions.vue'
import { useReveal } from './composables/useReveal'
import logo from './assets/images/logo.png'

useReveal()
const toast = ref('')
let toastTimer
function notify(message) {
  toast.value = message
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toast.value = '' }, 2300)
}
</script>

<template>
  <main class="app-shell">
    <HeroSection :logo="logo" />
    <QuickActions />
    <AboutSection />
    <ServicesSection />
    <ContactSection />
    <BranchesSection />
    <FeaturesSection />
    <PageActions @notify="notify" />
    <SiteFooter :logo="logo" />
  </main>
  <StickyActions />
  <Transition name="toast"><div v-if="toast" class="toast" role="status">{{ toast }}</div></Transition>
</template>
