<script setup>
import AppIcon from './AppIcon.vue'
import SectionTitle from './SectionTitle.vue'
import { services } from '../data/site'
</script>

<template>
  <section>
    <SectionTitle title="خدماتنا" />
    <div class="services reveal">
      <article v-for="service in services" :key="service.name" class="service-card">
        <span class="service-card__icon"><AppIcon :name="service.icon" :size="21" /></span><b>{{ service.name }}</b><small>{{ service.detail }}</small>
      </article>
    </div>
  </section>
</template>
