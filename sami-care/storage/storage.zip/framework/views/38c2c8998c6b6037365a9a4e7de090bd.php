<div class="d-flex gap-3 align-items-center">
  <img src="<?php echo e($data->feature_image ?? default_user_avatar()); ?>" alt="avatar" class="avatar avatar-40 rounded-pill">
  <div>
    <p class="m-0"><?php echo e($data->name ?? default_user_name()); ?></p>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($email)): ?>
    <small><?php echo e($email); ?></small>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
  </div>
</div><?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\branch\branch_id.blade.php ENDPATH**/ ?>