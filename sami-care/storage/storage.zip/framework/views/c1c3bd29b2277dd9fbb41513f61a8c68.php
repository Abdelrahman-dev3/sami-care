<?php echo csrf_field(); ?>
<?php if (! $__env->hasRenderedOnce('01ff22dc-9ecf-4e48-989c-191cfc03c1b1')): $__env->markAsRenderedOnce('01ff22dc-9ecf-4e48-989c-191cfc03c1b1'); ?>
    <style>
        .cafe-select-fix {
            background-position: right .75rem center;
            padding-right: 2.25rem;
        }

        [dir="rtl"] .cafe-select-fix {
            background-position: left .75rem center;
            padding-left: 2.25rem;
            padding-right: .75rem;
        }
    </style>
<?php endif; ?>

<div class="row g-3">
    <div class="col-md-6">
        <label class="form-label"><?php echo e(__('cafe.name')); ?></label>
        <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $item->name ?? '')); ?>" required>
    </div>
    <div class="col-md-6">
        <label class="form-label"><?php echo e(__('cafe.category')); ?></label>
        <select name="cafe_category_id" class="form-select cafe-select-fix" required>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>" <?php if(old('cafe_category_id', $item->cafe_category_id ?? '') == $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </select>
    </div>
    <div class="col-md-4">
        <label class="form-label"><?php echo e(__('cafe.price')); ?></label>
        <input type="number" min="0" step="0.01" name="price" class="form-control" value="<?php echo e(old('price', $item->price ?? '')); ?>" required>
    </div>
    <div class="col-md-4">
        <label class="form-label"><?php echo e(__('cafe.status')); ?></label>
        <select name="status" class="form-select cafe-select-fix" required>
            <option value="available" <?php if(old('status', $item->status ?? 'available') === 'available'): echo 'selected'; endif; ?>><?php echo e(__('cafe.available')); ?></option>
            <option value="unavailable" <?php if(old('status', $item->status ?? '') === 'unavailable'): echo 'selected'; endif; ?>><?php echo e(__('cafe.unavailable')); ?></option>
        </select>
    </div>
    <div class="col-md-4">
        <label class="form-label"><?php echo e(__('cafe.sort_order')); ?></label>
        <input type="number" min="0" name="sort_order" class="form-control" value="<?php echo e(old('sort_order', $item->sort_order ?? 0)); ?>">
    </div>
    <div class="col-md-8">
        <label class="form-label"><?php echo e(__('cafe.image')); ?></label>
        <input type="file" name="image" class="form-control" accept="image/*">
    </div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($item)): ?>
        <div class="col-md-4">
            <img src="<?php echo e($item->image_url); ?>" alt="<?php echo e($item->name); ?>" class="rounded" style="width: 96px; height: 96px; object-fit: cover;">
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <div class="col-12">
        <label class="form-label"><?php echo e(__('cafe.description')); ?></label>
        <textarea name="description" class="form-control" rows="4"><?php echo e(old('description', $item->description ?? '')); ?></textarea>
    </div>
    <div class="col-12 d-flex gap-2">
        <button class="btn btn-primary" type="submit"><?php echo e(__('cafe.save')); ?></button>
        <a class="btn btn-light" href="<?php echo e(route('backend.cafe.items.index')); ?>"><?php echo e(__('cafe.cancel')); ?></a>
    </div>
</div>
<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\cafe\items\form.blade.php ENDPATH**/ ?>