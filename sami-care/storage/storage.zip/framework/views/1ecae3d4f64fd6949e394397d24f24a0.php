

<?php $__env->startSection('title', __('cafe.items')); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('backend.cafe.partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h4 class="mb-0"><?php echo e(__('cafe.items')); ?></h4>
            <a href="<?php echo e(route('backend.cafe.items.create')); ?>" class="btn btn-primary">
                <i class="fa-solid fa-plus"></i> <?php echo e(__('cafe.add_item')); ?>

            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead>
                        <tr>
                            <th><?php echo e(__('cafe.item')); ?></th>
                            <th><?php echo e(__('cafe.category')); ?></th>
                            <th><?php echo e(__('cafe.price')); ?></th>
                            <th><?php echo e(__('cafe.status')); ?></th>
                            <th class="text-end"><?php echo e(__('cafe.actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center gap-3">
                                        <img src="<?php echo e($item->image_url); ?>" alt="<?php echo e($item->name); ?>" class="rounded" style="width: 52px; height: 52px; object-fit: cover;">
                                        <div>
                                            <strong><?php echo e($item->name); ?></strong>
                                            <div class="text-muted small"><?php echo e(\Illuminate\Support\Str::limit($item->description, 70)); ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo e($item->category?->name); ?></td>
                                <td><?php echo e(number_format($item->price, 2)); ?></td>
                                <td><span class="badge <?php echo e($item->status === 'available' ? 'bg-success' : 'bg-secondary'); ?>"><?php echo e($item->status === 'available' ? __('cafe.available') : __('cafe.unavailable')); ?></span></td>
                                <td class="text-end">
                                    <a class="btn btn-sm btn-soft-primary" href="<?php echo e(route('backend.cafe.items.edit', $item)); ?>"><i class="fa-solid fa-pen"></i></a>
                                    <form class="d-inline" method="POST" action="<?php echo e(route('backend.cafe.items.destroy', $item)); ?>" onsubmit="return confirm('<?php echo e(__('cafe.confirm_delete')); ?>')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-soft-danger" type="submit"><i class="fa-solid fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="5" class="text-center text-muted"><?php echo e(__('cafe.no_records')); ?></td></tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($items->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\cafe\items\index.blade.php ENDPATH**/ ?>