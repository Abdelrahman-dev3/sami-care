

<?php $__env->startSection('title', __('cafe.orders')); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('backend.cafe.partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <div class="card-header">
            <h4 class="mb-0"><?php echo e(__('cafe.orders')); ?></h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead>
                        <tr>
                            <th><?php echo e(__('cafe.order_number')); ?></th>
                            <th><?php echo e(__('cafe.table')); ?></th>
                            <th><?php echo e(__('cafe.items')); ?></th>
                            <th><?php echo e(__('cafe.total')); ?></th>
                            <th><?php echo e(__('cafe.status')); ?></th>
                            <th><?php echo e(__('cafe.time')); ?></th>
                            <th class="text-end"><?php echo e(__('cafe.actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><strong><?php echo e($order->order_number); ?></strong></td>
                                <td><?php echo e($order->table?->name); ?></td>
                                <td><?php echo e($order->items->sum('quantity')); ?></td>
                                <td><?php echo e(number_format($order->total, 2)); ?></td>
                                <td><?php echo $order->status_label; ?></td>
                                <td><?php echo e($order->created_at?->format('Y-m-d H:i')); ?></td>
                                <td class="text-end">
                                    <a class="btn btn-sm btn-soft-primary" href="<?php echo e(route('backend.cafe.orders.show', $order)); ?>">
                                        <i class="fa-solid fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="7" class="text-center text-muted"><?php echo e(__('cafe.no_records')); ?></td></tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($orders->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views/backend/cafe/orders/index.blade.php ENDPATH**/ ?>