

<?php $__env->startSection('title', __($module_action . ' ' . $module_title)); ?>

<?php $__env->startSection('content'); ?>
    <div class="card mb-4">
        <div class="card-body">

            <div class="row mt-4">
                <div class="col">
                    <table id="datatable" class="table table-bordered table-responsive">
                        <thead>
                            <tr>
                                <th>
                                    <?php echo e(__('notification.lbl_text')); ?>

                                </th>
                                <th>
                                    <?php echo e(__('notification.lbl_module')); ?>

                                </th>
                                <th>
                                    <?php echo e(__('notification.lbl_update')); ?>

                                </th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $$module_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module_name_singular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                $row_class = '';
                                $span_class = '';
                                if ($module_name_singular->read_at == '') {
                                    $row_class = 'bg-soft-gray';
                                    $span_class = 'fw-bold';
                                }
                                ?>
                                <tr class="<?php echo e($row_class); ?>">
                                    <td>
                                            <span class="<?php echo e($span_class); ?>">
                                                <?php echo e($module_name_singular->data['subject']); ?>

                                            </span>
                                    </td>
                                    <td>
                                        
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($module_name_singular->data['data']['service_name'])): ?>
                                        <?php echo e($module_name_singular->data['data']['service_name'] ?? 'no service name'); ?>

                                    <?php else: ?>
                                        <?php echo e($module_name_singular->data['data']['package_name'] ?? '-'); ?>

                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($module_name_singular->updated_at->diffForHumans()); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3" class="text-center"><?php echo e(__('No data found')); ?></td>
                                </tr>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <div class="row">
                <div class="col-7">
                    <div class="float-left">
                        <?php echo e(__('Total')); ?> <?php echo e($$module_name->total()); ?> <?php echo e(__($module_name)); ?>

                    </div>
                </div>
                <div class="col-5">
                    <div class="float-end">
                        <?php echo $$module_name->render(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\notifications\index.blade.php ENDPATH**/ ?>