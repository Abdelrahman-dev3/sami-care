

<?php $__env->startSection('title', __('cafe.tables')); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('backend.cafe.partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h4 class="mb-0"><?php echo e(__('cafe.tables')); ?></h4>
            <a href="<?php echo e(route('backend.cafe.tables.create')); ?>" class="btn btn-primary">
                <i class="fa-solid fa-plus"></i> <?php echo e(__('cafe.add_table')); ?>

            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead>
                        <tr>
                            <th><?php echo e(__('cafe.table')); ?></th>
                            <th><?php echo e(__('cafe.qr_code')); ?></th>
                            <th><?php echo e(__('cafe.orders')); ?></th>
                            <th><?php echo e(__('cafe.status')); ?></th>
                            <th class="text-end"><?php echo e(__('cafe.actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <strong><?php echo e($table->name); ?></strong>
                                    <div class="small text-muted"><?php echo e($table->code); ?></div>
                                    <a class="small" href="<?php echo e($table->order_url); ?>" target="_blank"><?php echo e($table->order_url); ?></a>
                                </td>
                                <td><img src="<?php echo e($table->qr_url); ?>" alt="<?php echo e($table->name); ?>" style="width: 86px; height: 86px;"></td>
                                <td><?php echo e($table->orders_count); ?></td>
                                <td><span class="badge <?php echo e($table->status ? 'bg-success' : 'bg-secondary'); ?>"><?php echo e($table->status ? __('cafe.active') : __('cafe.inactive')); ?></span></td>
                                <td class="text-end">
                                    <a class="btn btn-sm btn-soft-primary" href="<?php echo e(route('backend.cafe.tables.edit', $table)); ?>"><i class="fa-solid fa-pen"></i></a>
                                    <form class="d-inline" method="POST" action="<?php echo e(route('backend.cafe.tables.destroy', $table)); ?>" onsubmit="return confirm('<?php echo e(__('cafe.confirm_delete')); ?>')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-soft-danger" type="submit"><i class="fa-solid fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="5" class="text-center text-muted"><?php echo e(__('cafe.no_records')); ?></td></tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($tables->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\cafe\tables\index.blade.php ENDPATH**/ ?>