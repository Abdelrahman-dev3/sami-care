<div class="d-flex gap-2 align-items-center">
  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Auth::user()->can('edit_notification_template')): ?>
    <a href="<?php echo e(route("backend.notification-templates.edit", $data->id)); ?>" class="btn btn-soft-primary btn-sm" data-bs-toggle="tooltip" title="<?php echo e(__('messages.edit')); ?> "> <i class="fa-solid fa-pen-clip"></i></a>
  <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
  

</div>
<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\Modules\NotificationTemplate\Resources\views\backend\notificationtemplates\action_column.blade.php ENDPATH**/ ?>