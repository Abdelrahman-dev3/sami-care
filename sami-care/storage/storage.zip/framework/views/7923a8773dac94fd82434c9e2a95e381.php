<?php echo csrf_field(); ?>
<div class="row g-3">
    <div class="col-md-6">
        <label class="form-label"><?php echo e(__('cafe.name')); ?></label>
        <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $category->name ?? '')); ?>" required>
    </div>
    <div class="col-md-3">
        <label class="form-label"><?php echo e(__('cafe.sort_order')); ?></label>
        <input type="number" min="0" name="sort_order" class="form-control" value="<?php echo e(old('sort_order', $category->sort_order ?? 0)); ?>">
    </div>
    <div class="col-md-3">
        <label class="form-label"><?php echo e(__('minimum duration')); ?></label>
        <input type="number" min="0" name="durMin" class="form-control" value="<?php echo e(old('durMin', $category->durMin ?? 0)); ?>">
    </div>
    <div class="col-md-3">
        <label class="form-label"><?php echo e(__('maximum duration')); ?></label>
        <input type="number" min="0" name="durMax" class="form-control" value="<?php echo e(old('durMax', $category->durMax ?? 0)); ?>">
    </div>
    <div class="col-md-3">
        <label class="form-label"><?php echo e(__('price from')); ?></label>
        <input type="number" min="0" name="price_from" class="form-control" value="<?php echo e(old('price_from', $category->price_from ?? 0)); ?>">
    </div>
    <div class="col-md-3">
        <label class="form-label"><?php echo e(__('image')); ?></label>
        <input type="file" name="image" class="form-control">
    </div>
    <div class="col-md-3 d-flex align-items-end">
        <div class="form-check form-switch mb-2">
            <input type="hidden" name="status" value="0">
            <input class="form-check-input" type="checkbox" name="status" value="1" id="status" <?php if(old('status', $category->status ?? true)): echo 'checked'; endif; ?>>
            <label class="form-check-label" for="status"><?php echo e(__('cafe.active')); ?></label>
        </div>
    </div>
    <div class="col-12">
        <label class="form-label"><?php echo e(__('cafe.description')); ?></label>
        <textarea name="description" class="form-control" rows="4"><?php echo e(old('description', $category->description ?? '')); ?></textarea>
    </div>
    <div class="col-12 d-flex gap-2">
        <button class="btn btn-primary" type="submit"><?php echo e(__('cafe.save')); ?></button>
        <a class="btn btn-light" href="<?php echo e(route('backend.cafe.categories.index')); ?>"><?php echo e(__('cafe.cancel')); ?></a>
    </div>
</div>
<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\cafe\categories\form.blade.php ENDPATH**/ ?>