<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn btn-primary'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\components\button.blade.php ENDPATH**/ ?>