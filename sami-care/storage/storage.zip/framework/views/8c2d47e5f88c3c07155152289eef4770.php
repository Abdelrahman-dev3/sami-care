<?php $__env->startComponent('mail::message'); ?>
<?php echo $templateData ?? ''; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\mail\markdown.blade.php ENDPATH**/ ?>