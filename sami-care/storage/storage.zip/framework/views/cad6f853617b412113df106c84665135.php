<?php
$required = (Str::contains($field['rules'], 'required')) ? "required" : "";
$required_mark = ($required != "") ? '<span class="text-danger"> <strong>*</strong> </span>' : '';
?>

<div class="form-group mb-3 <?php echo e($errors->has($field['name']) ? ' has-error' : ''); ?>">
    <div class="checkbox">
        <label>
            <input type='hidden' value='0' name='<?php echo e($field['name']); ?>' class='form-label'>
            <input name=" <?php echo e($field['name']); ?>" value="<?php echo e(\Illuminate\Support\Arr::get($field, 'value', '1')); ?>" type="checkbox" <?php if(old($field['name'], setting($field['name']))): ?> checked="checked" <?php endif; ?>>
            <?php echo e($field['label']); ?>

        </label> <?php echo $required_mark; ?>


        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->has($field['name'])): ?> <small class="help-block"><?php echo e($errors->first($field['name'])); ?></small> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\settings\fields\checkbox.blade.php ENDPATH**/ ?>