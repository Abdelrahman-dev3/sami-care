<?php $__env->startSection('title'); ?>
    <?php echo e(__($module_action)); ?> <?php echo e(__($module_title)); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card card-block card-stretch">
                <div class="card-body p-0">
                    <div class="d-flex justify-content-between align-items-center p-3 flex-wrap gap-3">
                        <h5 class="font-weight-bold"><?php echo e($pageTitle ?? __('messages.edit')); ?></h5>
                        <a href="<?php echo e(route('backend.notification-templates.index')); ?>"
                            class="float-right btn btn-sm btn-primary"><i class="fa fa-angle-double-left"></i>
                            <?php echo e(__('messages.back')); ?></a>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <?php echo e(Form::model($data, ['route' => ['backend.notification-templates.update', $data->id], 'method' => 'patch', 'button-loader' => 'true'])); ?>

            <?php echo e(Form::hidden('id', null)); ?>

            <?php echo e(Form::hidden('type', $data->type ?? null)); ?>

            <?php echo e(Form::hidden('defaultNotificationTemplateMap[template_id]', $data->id ?? null)); ?>


            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label><?php echo e(__('Type')); ?> : <span class="text-danger">*</span></label>
                        <select name="type" class="form-control select2js" id="type"
                            data-ajax--url="<?php echo e(route('backend.notificationtemplates.ajax-list', ['type' => 'constants_key', 'data_type' => 'notification_type'])); ?>"
                            data-ajax--cache="true" required disabled>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($data->type)): ?>
                                <option value="<?php echo e($data->type); ?>" selected><?php echo e($data->constant->name ?? ''); ?></option>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </select>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                        <label><?php echo e(__('To')); ?> : <span class="text-danger">*</span></label><br>
                        <select name="to[]" id="toSelect" class="form-control select2"
                            data-ajax--url="<?php echo e(route('backend.notificationtemplates.ajax-list', ['type' => 'constants_key', 'data_type' => 'notification_to'])); ?>"
                            data-ajax--cache="true" multiple required>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($data) && $data->to != null): ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = json_decode($data->to); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $to): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($to); ?>" selected><?php echo e($to); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </select>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                        <?php
                            $toValues = json_decode($data->to, true) ?? [];
                        ?>
                        <?php echo e(Form::label('user_type', __('messages.user_type') . ' <span class="text-danger">*</span>', ['class' => 'form-control-label'], false)); ?>

                        <?php echo e(Form::select('defaultNotificationTemplateMap[user_type]', [], null, ['id' => 'userTypeSelect', 'class' => 'form-control select2js', 'required'])); ?>

                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                        <label class="form-label" for="status"><?php echo e(__('messages.status')); ?> :</label>
                        <select class="form-control" name="status" id="status">
                            <option value="1" <?php echo e($data->status == 1 ? 'selected' : ''); ?>>Active</option>
                            <option value="0" <?php echo e($data->status == 0 ? 'selected' : ''); ?>>Inactive</option>
                        </select>
                    </div>
                </div>

                <div class="col-md-12 mt-3">
                    <div class="form-group">
                        <label><?php echo e(__('Parameters')); ?> :</label><br>
                        <div class="main_form">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($buttonTypes)): ?>
                                <?php echo $__env->make(
                                    'notificationtemplate::backend.notificationtemplates.perameters-buttons',
                                    ['buttonTypes' => $buttonTypes]
                                , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 mt-3">
                    <div class="form-group mb-3">
                        <h4><?php echo e(__('messages.notification_template')); ?></h4>
                    </div>
                    <div class="form-group">
                        <label class="float-left"><?php echo e(__('messages.subject')); ?> :</label>
                        <?php echo e(Form::text('defaultNotificationTemplateMap[notification_subject]', null, ['class' => 'form-control'])); ?>

                    </div>
                    <div class="form-group">
                        <label><?php echo e(__('messages.template')); ?> :</label>
                        <?php echo e(Form::hidden('defaultNotificationTemplateMap[language]', 'en')); ?>

                        <?php echo e(Form::textarea('defaultNotificationTemplateMap[notification_template_detail]', null, ['class' => 'form-control textarea tinymce-template', 'id' => 'mytextarea_mail'])); ?>

                    </div>
                </div>

                <div class="col-md-6 mt-3">
                    <div class="form-group mb-3">
                        <h4><?php echo e(__('messages.mail_template')); ?></h4>
                    </div>
                    <div class="form-group">
                        <label class="float-left"><?php echo e(__('messages.subject')); ?> :</label>
                        <?php echo e(Form::text('defaultNotificationTemplateMap[subject]', null, ['class' => 'form-control'])); ?>

                        <?php echo e(Form::hidden('defaultNotificationTemplateMap[status]', 1, ['class' => 'form-control'])); ?>

                    </div>
                    <div class="form-group">
                        <label><?php echo e(__('messages.template')); ?> :</label>
                        <?php echo e(Form::hidden('defaultNotificationTemplateMap[language]', 'en')); ?>

                        <?php echo e(Form::textarea('defaultNotificationTemplateMap[template_detail]', null, ['class' => 'form-control textarea tinymce-template', 'id' => 'mytextarea'])); ?>

                    </div>

                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12 pt-2">
                <button id="saveButton" type="submit" class="btn btn-primary">
                    <span id="buttonText">
                        <i class="far fa-save"></i> <?php echo e(__('save')); ?>

                    </span>
                    <span id="loader" class="d-none">
                        <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                        Loading...
                    </span>
                </button>
                
                
                    <button type="button" onclick="window.location.href='<?php echo e(route('backend.notification-templates.index')); ?>';" class="btn btn-outline-primary">
                        <i class="fa-solid fa-angles-left"></i> <?php echo e(__('close')); ?>

                        <i class="md md-lock-open"></i>
                    </button>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script>
         $(document).ready(function() {
            // Initialize TinyMCE
            const saveButton = $("#saveButton");
            const buttonText = $("#buttonText");
            const loader = $("#loader");

        // Disable save button on form submission
        $("form").on("submit", function () {
            saveButton.prop("disabled", true);
            buttonText.addClass("d-none");
            loader.removeClass("d-none");
        });

            (function($) {
                $(document).ready(function() {
                    tinymceEditor('.tinymce-templates', ' ', function(ed) {
                    }, 450)
                });

            })(jQuery);

            // Initialize Select2
            $('.select2js').select2();
            $('.select2-tag').select2({
                tags: true,
                createTag: function(params) {
                    if (params.term.length > 2) {
                        return {
                            id: params.term,
                            text: params.term,
                            newTag: true
                        };
                    }
                    return null;
                }
            });


            // Handle change event for 'user_type' select
            $('select[name="defaultNotificationTemplateMap[user_type]"]').on('change', function() {
                var userType = $(this).val();
                var type = $('select[name="type"]').val();
                $.ajax({
                    url: "<?php echo e(route('backend.notificationtemplates.fetchnotification_data')); ?>",
                    method: "GET",
                    data: {
                        user_type: userType,
                        type: type
                    },
                    success: function(response) {
                        if (response.success) {
                            var data = response.data;
                            $("input[name='defaultNotificationTemplateMap[subject]']").val(data
                                .subject);
                            tinymce.get('mytextarea').setContent(data.template_detail || '');
                            $("input[name='defaultNotificationTemplateMap[notification_message]']")
                                .val(data.notification_message);
                            $("input[name='defaultNotificationTemplateMap[notification_link]']")
                                .val(data.notification_link);

                            $("input[name='defaultNotificationTemplateMap[notification_subject]']").val(
                                data.notification_subject || '');
                            tinymce.get('mytextarea_mail').setContent(data
                                .notification_template_detail || '');
                        } else {
                            $("input[name='defaultNotificationTemplateMap[subject]']").val('');
                            tinymce.get('mytextarea').setContent('');
                            $("input[name='defaultNotificationTemplateMap[notification_message]']")
                                .val('');
                            $("input[name='defaultNotificationTemplateMap[notification_link]']")
                                .val('');

                            $("input[name='defaultNotificationTemplateMap[notification_subject]']").val(
                                '');
                            tinymce.get('mytextarea_mail').setContent('');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error(error);
                    }
                });
            });

            var toSelect = $('#toSelect');
            var userTypeSelect = $('#userTypeSelect');

            function updateUserTypeOptions(selectedValues) {
                userTypeSelect.empty();
                if (selectedValues) {
                    selectedValues.forEach(function(value) {
                        userTypeSelect.append(new Option(value, value));
                    });
                }
                userTypeSelect.trigger('change');
            }

            var initialSelectedValues = toSelect.val();
            updateUserTypeOptions(initialSelectedValues);

            toSelect.on('change', function() {
                var selectedValues = $(this).val();
                updateUserTypeOptions(selectedValues);
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\Modules\NotificationTemplate\Resources\views\backend\notificationtemplates\form.blade.php ENDPATH**/ ?>