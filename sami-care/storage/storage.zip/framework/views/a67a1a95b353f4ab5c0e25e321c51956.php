<div class="d-flex gap-3 align-items-center">
  <img src="<?php echo e($data->feature_image ?? default_user_avatar()); ?>" alt="avatar" class="avatar avatar-40 rounded-pill">
  <div>
      <h6 class="m-0">
          <a href="<?php echo e($link); ?>"><?php echo e($data->name ?? default_user_name()); ?></a>
      </h6>
  </div>
</div><?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\Modules\Category\Resources\views\backend\categories\branch_id.blade.php ENDPATH**/ ?>