

<?php $__env->startSection('title'); ?> <?php echo e(__($module_action)); ?> <?php echo e(__($module_title)); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between">
            <div>
                <h4 class="card-title mb-0">
                    <i class="<?php echo e($module_icon); ?>"></i> <?php echo e(__($module_title)); ?>

                </h4>
                <div class="small text-medium-emphasis"><?php echo app('translator')->get(":module_name Management Dashboard", ['module_name'=>Str::title($module_name)]); ?></div>
            </div>
            <div class="btn-toolbar d-block" role="toolbar" aria-label="Toolbar with buttons">
                <a href="<?php echo e(route("backend.$module_name.create")); ?>" class="btn btn-outline-success m-1" data-bs-toggle="tooltip" title="Create New"><i class="fas fa-plus-circle"></i> <?php echo app('translator')->get("Create new :module_name", ['module_name'=>Str::title($module_name)]); ?></a>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col">

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($backups)): ?>
                <table id="datatable" class="table table-bordered table-hover table-responsive">
                    <thead>
                        <tr>
                            <th>
                                #
                            </th>
                            <th>
                                <?php echo app('translator')->get('File'); ?>
                            </th>
                            <th>
                                <?php echo app('translator')->get('Size'); ?>
                            </th>
                            <th>
                                <?php echo app('translator')->get('Date'); ?>
                            </th>
                            <th>
                                <?php echo app('translator')->get('Age'); ?>
                            </th>
                            <th class="text-end">
                                <?php echo app('translator')->get('Action'); ?>
                            </th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $backups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $backup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e(++$key); ?>

                            </td>
                            <td>
                                <?php echo e($backup['file_name']); ?>

                            </td>
                            <td>
                                <?php echo e($backup['file_size']); ?>

                            </td>
                            <td>
                                <?php echo e($backup['date_created']); ?>

                            </td>
                            <td>
                                <?php echo e($backup['date_ago']); ?>

                            </td>
                            <td class="text-end">
                                <a href="<?php echo e(route("backend.$module_name.download", $backup['file_name'])); ?>" class="btn btn-primary m-1 btn-sm" data-bs-toggle="tooltip" title="<?php echo app('translator')->get('Download File'); ?>"><i class="fas fa-cloud-download-alt"></i>&nbsp;<?php echo app('translator')->get('Download'); ?></a>

                                <a href="<?php echo e(route("backend.$module_name.delete", $backup['file_name'])); ?>" class="btn btn-danger m-1 btn-sm" data-bs-toggle="tooltip" title="<?php echo app('translator')->get('Delete File'); ?>"><i class="fas fa-trash"></i>&nbsp;<?php echo app('translator')->get('Delete'); ?></a>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <div class="text-center">
                    <h4><?php echo app('translator')->get('There are no backups'); ?></h4>
                </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\backups\backups.blade.php ENDPATH**/ ?>