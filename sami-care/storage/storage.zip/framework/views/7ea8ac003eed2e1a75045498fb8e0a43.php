<div class="row">
    <div class="col">
        <small class="float-end text-muted">
            <?php echo e($slot); ?>

        </small>
    </div>
</div><?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\components\backend\section-footer.blade.php ENDPATH**/ ?>