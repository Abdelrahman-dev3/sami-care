

<?php $__env->startSection('title'); ?>
<?php echo e(__($module_action)); ?> <?php echo e(__($module_title)); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body" style="overflow-x: auto;">
        <h3 class="mb-4"><?php echo e(__('messages.gift_cards_list')); ?></h3>
        <table class="table table-bordered table-striped">
            <thead>
            <tr>
                <th><?php echo e(__('messages.recipient_name')); ?></th>
                <th><?php echo e(__('messages.recipient_phone')); ?></th>
                <th>رسالة المرسل لمستلم الهدية</th>
                <th><?php echo e(__('messages.selected_services')); ?></th>
                <th><?php echo e(__('messages.subtotal')); ?></th>
                <th><?php echo e(__('booking.lbl_payment_status')); ?></th>
                <th>Gift Link</th>
                <th>SMS</th>
                <th><?php echo e(__('messages.created_at')); ?></th>
                <th><?php echo e(__('messages.action')); ?></th>
            </tr>
            </thead>
            <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $gifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                <td><?php echo e($gift->recipient_name ?? '-'); ?></td> 
                <td><?php echo e($gift->recipient_phone ?? '-'); ?></td>
                <td title="<?php echo e($gift->message ?? ''); ?>">
                    <?php echo e(\Illuminate\Support\Str::limit($gift->message ?? '-', 80)); ?>

                </td>
                <td>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_2 = true; $__currentLoopData = $gift->services_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <?php
                            $serviceName = is_array($service->name)
                                ? ($service->name[app()->getLocale()] ?? $service->name['ar'] ?? $service->name['en'] ?? reset($service->name))
                                : $service->name;
                        ?>
                        <span class="badge bg-primary"><?php echo e($serviceName); ?></span> <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        -
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </td>
                <td><?php echo e($gift->subtotal ?? '-'); ?></td>
                <td style="text-align: center;font-size: 16px;">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($gift->payment_status == 1): ?>
                        <span class="badge bg-success"><?php echo e(__('gift.paid')); ?></span>
                    <?php else: ?>
                        <span class="badge bg-warning text-dark"><?php echo e(__('gift.unpaid')); ?></span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </td>
                <td>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($gift->claim_url): ?>
                        <a href="<?php echo e($gift->claim_url); ?>" target="_blank" class="btn btn-soft-primary btn-sm">Open</a>
                    <?php else: ?>
                        -
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </td>
                <td>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($gift->send_status === 'sent'): ?>
                        <span class="badge bg-success">sent</span>
                    <?php elseif($gift->send_status === 'failed'): ?>
                        <span class="badge bg-danger">failed</span>
                    <?php else: ?>
                        <span class="badge bg-secondary">pending</span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($gift->sent_at): ?>
                        <div><small><?php echo e($gift->sent_at->format('Y-m-d H:i')); ?></small></div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($gift->send_error): ?>
                        <div class="text-danger" title="<?php echo e($gift->send_error); ?>">
                            <small><?php echo e(\Illuminate\Support\Str::limit($gift->send_error, 80)); ?></small>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </td>
                <td><?php echo e($gift->created_at ? $gift->created_at->format('Y-m-d') : '-'); ?></td>
                <td>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Auth::user()->can('delete_gift')): ?>
                        <a href="<?php echo e(route('gift.delete', $gift->id)); ?>" id="delete-bookings-138" class="btn btn-soft-danger btn-sm" onclick="return confirm('<?php echo e(__('messages.confirm_delete')); ?>');">
                            <i class="fa-solid fa-trash"></i>
                        </a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="10" class="text-center"><?php echo e(__('messages.no_gift_cards')); ?></td>
                </tr>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
       
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\gift\index_datatable.blade.php ENDPATH**/ ?>