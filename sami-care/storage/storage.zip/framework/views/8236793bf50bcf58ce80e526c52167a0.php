

<?php $__env->startSection('title', __('cafe.edit_item')); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('backend.cafe.partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <div class="card-header"><h4 class="mb-0"><?php echo e(__('cafe.edit_item')); ?></h4></div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('backend.cafe.items.update', $item)); ?>" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo $__env->make('backend.cafe.items.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\cafe\items\edit.blade.php ENDPATH**/ ?>