<div class="text-end">
    <button type='button' data-slot-module="<?php echo e($data->id); ?>"  data-slot-target='#slot-form-offcanvas' data-slot-event='staff_slot_assign' class='btn btn-secondary btn-icon btn-sm'data-bs-toggle="tooltip" data-bs-title="<?php echo e(__('Available Slots')); ?>" ><i class="fa-solid fa-calendar-days"></i></button>
    <a href="<?php echo e(route('backend.users.show', $data)); ?>" class="btn btn-success btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-title="<?php echo e(__('labels.backend.show')); ?>"><i class="fa-solid fa-eye"></i></a>
    <a href="<?php echo e(route('backend.users.edit', $data)); ?>" class="btn btn-primary btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-title="<?php echo e(__('labels.backend.edit')); ?>"><i class="fa-solid fa-pen-clip"></i></a>
    <a href="<?php echo e(route('backend.users.changePassword', $data)); ?>" class="btn btn-info btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-title="<?php echo e(__('labels.backend.changePassword')); ?>"><i class="fas fa-key"></i></a>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($data->status != 2 && $data->id != 1): ?>
    <a href="<?php echo e(route('backend.users.block', $data)); ?>" class="btn btn-danger btn-icon btn-sm" data-method="PATCH" data-token="<?php echo e(csrf_token()); ?>" data-bs-toggle="tooltip" data-bs-title="<?php echo e(__('labels.backend.block')); ?>" data-confirm="<?php echo e(__('messages.are_you_sure?')); ?>"><i class="fas fa-ban"></i></a>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($data->status == 2): ?>
    <a href="<?php echo e(route('backend.users.unblock', $data)); ?>" class="btn btn-info btn-icon btn-sm" data-method="PATCH" data-token="<?php echo e(csrf_token()); ?>" data-bs-toggle="tooltip" data-bs-title="<?php echo e(__('labels.backend.unblock')); ?>" data-confirm="<?php echo e(__('messages.are_you_sure?')); ?>"><i class="fas fa-check"></i></a>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($data->id != 1): ?>
    <a href="<?php echo e(route('backend.users.destroy', $data)); ?>" class="btn btn-danger btn-icon btn-sm" data-method="DELETE" data-token="<?php echo e(csrf_token()); ?>" data-bs-toggle="tooltip" data-bs-title="<?php echo e(__('labels.backend.delete')); ?>" data-confirm="<?php echo e(__('messages.are_you_sure?')); ?>"> <i class="fa-solid fa-trash"></i></a>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($data->email_verified_at == null): ?>
    <a href="<?php echo e(route('backend.users.emailConfirmationResend', $data->id)); ?>" class="btn btn-primary btn-icon btn-sm" data-bs-toggle="tooltip" data-bs-title="<?php echo app('translator')->get('send_confirmation_email'); ?>"><i class="fas fa-envelope"></i></a>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\includes\user_actions.blade.php ENDPATH**/ ?>