

<?php $__env->startSection('title'); ?> <?php echo e(__($module_action)); ?> <?php echo e(__($module_title)); ?> <?php $__env->stopSection(); ?>

<?php $__env->startPush('after-styles'); ?>
    

<?php $__env->stopPush(); ?>
<?php $__env->startSection('banner-button'); ?>
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Auth::user()->can('add_booking')): ?>
<button type="button" class="btn btn-primary" data-booking-create><i class="fa-solid fa-plus"></i> <?php echo e(__('booking.lbl_new_appointment')); ?></button>
<button type="button" class="btn btn-soft-primary" data-home-booking-create data-bs-toggle="offcanvas" data-bs-target="#home-booking-form" aria-controls="home-booking-form">
    <i class="fa-solid fa-house me-2"></i><?php echo e(__('messagess.home_services')); ?>

</button>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Auth::user()->can('booking_booking_tableview')): ?>
<a href="<?php echo e(route("backend.$module_name.datatable_view")); ?>" class="btn btn-dark"><i class="fa-solid fa-table"></i> <?php echo e(__('messages.datatable_view')); ?></a>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">
      <div data-render="app">
        <calendar-view
          slot-duration="<?php echo e(setting('slot_duration')); ?>"
          status="<?php echo e(json_encode($statusList)); ?>"
          :branch-id="<?php echo e($selected_branch->id ?? 0); ?>"
          :can-reorder="<?php echo e(auth()->user()->can('view_booking') ? 'true' : 'false'); ?>"
          date="<?php echo e(\Carbon\Carbon::parse($date)->toDateString()); ?>"
          ></calendar-view>
        <home-booking-form></home-booking-form>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script src="<?php echo e(mix("modules/booking/script.js")); ?>"></script>
<script>
document.addEventListener('click', function (event) {
    if (!event.target.closest('[data-booking-create]')) {
        if (!event.target.closest('[data-home-booking-create]')) {
            return;
        }

        if (typeof window.openHomeBookingForm === 'function') {
            window.openHomeBookingForm();
            return;
        }

        const homeBookingElement = document.getElementById('home-booking-form');
        if (homeBookingElement && typeof bootstrap !== 'undefined' && bootstrap.Offcanvas) {
            bootstrap.Offcanvas.getOrCreateInstance(homeBookingElement).show();
        }

        window.dispatchEvent(new CustomEvent('home-booking:create'));
        return;
    }

    window.dispatchEvent(new CustomEvent('booking:create'));
});
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\Modules\Booking\Resources\views\backend\bookings\index.blade.php ENDPATH**/ ?>