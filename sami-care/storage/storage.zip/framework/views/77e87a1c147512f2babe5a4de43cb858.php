

<?php $__env->startSection('title', __('blog.title')); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('backend.blogs.partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h4 class="mb-0"><?php echo e(__('blog.title')); ?></h4>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add_blog')): ?>
                <a href="<?php echo e(route('backend.blogs.create')); ?>" class="btn btn-primary">
                    <i class="fa-solid fa-plus"></i> <?php echo e(__('blog.add_blog')); ?>

                </a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead>
                        <tr>
                            <th><?php echo e(__('blog.blog')); ?></th>
                            <th><?php echo e(__('blog.published_at')); ?></th>
                            <th><?php echo e(__('blog.status')); ?></th>
                            <th class="text-end"><?php echo e(__('blog.actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php ($frontendBlogUrl = rtrim(config('app.frontend_url'), '/').'/blog/'.$blog->slug); ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center gap-3">
                                        <img src="<?php echo e($blog->image_url); ?>" alt="<?php echo e($blog->title); ?>" class="rounded" style="width: 64px; height: 64px; object-fit: cover;">
                                        <div>
                                            <strong><?php echo e($blog->title); ?></strong>
                                            <div class="text-muted small"><?php echo e(\Illuminate\Support\Str::limit($blog->excerpt ?: strip_tags($blog->content), 90)); ?></div>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($blog->status): ?>
                                                <a href="<?php echo e($frontendBlogUrl); ?>" class="small" target="_blank"><?php echo e(__('blog.view_public')); ?></a>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo e($blog->published_at ? $blog->published_at->format('Y-m-d H:i') : '-'); ?></td>
                                <td>
                                    <span class="badge <?php echo e($blog->status ? 'bg-success' : 'bg-secondary'); ?>">
                                        <?php echo e($blog->status ? __('blog.active') : __('blog.inactive')); ?>

                                    </span>
                                </td>
                                <td class="text-end">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_blog')): ?>
                                        <a class="btn btn-sm btn-soft-primary" href="<?php echo e(route('backend.blogs.edit', $blog)); ?>" title="<?php echo e(__('blog.edit_blog')); ?>">
                                            <i class="fa-solid fa-pen"></i>
                                        </a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_blog')): ?>
                                        <form class="d-inline" method="POST" action="<?php echo e(route('backend.blogs.destroy', $blog)); ?>" onsubmit="return confirm('<?php echo e(__('blog.confirm_delete')); ?>')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-sm btn-soft-danger" type="submit" title="<?php echo e(__('blog.delete')); ?>">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center text-muted"><?php echo e(__('blog.no_records')); ?></td>
                            </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php echo e($blogs->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\blogs\index.blade.php ENDPATH**/ ?>