<div class="text-end d-flex gap-2 align-items-center">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_'.$module_name)): ?>
        <button type="button" class="btn btn-soft-primary btn-sm" data-crud-id="<?php echo e($data->id); ?>" title="<?php echo e(__('messages.edit')); ?> " data-bs-toggle="tooltip"> <i class="fa-solid fa-pen-clip"></i></button>
    <?php endif; ?>
    <a href="<?php echo e(route("backend.$module_name.show", $data->id)); ?>" class="btn btn-soft-success btn-sm" data-bs-toggle="tooltip" title="<?php echo e(__('labels.backend.show')); ?>"><i class="fas fa-eye"></i></a>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_'.$module_name)): ?>
        <a href="<?php echo e(route("backend.$module_name.destroy", $data->id)); ?>" id="delete-<?php echo e($module_name); ?>-<?php echo e($data->id); ?>" class="btn btn-soft-danger btn-sm" data-type="ajax" data-method="DELETE" data-token="<?php echo e(csrf_token()); ?>" data-bs-toggle="tooltip" title="<?php echo e(__('messages.delete')); ?>" data-confirm="<?php echo e(__('messages.are_you_sure?')); ?>"> <i class="fa-solid fa-trash"></i></a>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\Modules\Constant\Resources\views\backend\constants\action_column.blade.php ENDPATH**/ ?>