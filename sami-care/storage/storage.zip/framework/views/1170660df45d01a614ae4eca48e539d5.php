<?php
$required = (Str::contains($field['rules'], 'required')) ? "required" : "";
$required_mark = ($required != "") ? '<span class="text-danger"> <strong>*</strong> </span>' : '';
?>

<div class="form-group mb-3 <?php echo e($errors->has($field['name']) ? ' has-error' : ''); ?>">
    <label for="<?php echo e($field['name']); ?>" class='form-label'> <strong><?php echo e($field['label']); ?></strong> (<?php echo e($field['name']); ?>)</label> <?php echo $required_mark; ?>

    <select name="<?php echo e($field['name']); ?>" class="form-control <?php echo e(Arr::get( $field, 'class')); ?> <?php echo e($errors->has($field['name']) ? ' is-invalid' : ''); ?>" id="<?php echo e($field['name']); ?>" <?php echo e($required); ?>>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = Arr::get($field, 'options', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php if( old($field['name'], setting($field['name'])) == $val ): ?> selected  <?php endif; ?> value="<?php echo e($val); ?>"><?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </select>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->has($field['name'])): ?> <small class="invalid-feedback"><?php echo e($errors->first($field['name'])); ?></small> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\settings\fields\select.blade.php ENDPATH**/ ?>