<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir="<?php echo e(language_direction()); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title', app_name()); ?> | <?php echo e(app_name()); ?></title>

    <link rel="stylesheet" href="<?php echo e(mix('css/libs.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(mix('css/backend.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('custom-css/dashboard.css')); ?>">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(language_direction() == 'rtl'): ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/rtl.css')); ?>">
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Almarai:wght@300;400;700;800&display=swap" rel="stylesheet">

    <style>
        body {
            min-height: 100vh;
            margin: 0;
            background: #f6f7f9;
            font-family: 'Almarai', sans-serif;
        }

        .dashboard-auth-shell {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .dashboard-auth-header {
            height: 72px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-bottom: 1px solid rgba(17, 24, 39, 0.08);
            background: #fff;
        }

        .dashboard-auth-brand {
            color: #1f2937 !important;
            font-size: 20px;
            font-weight: 800;
            text-decoration: none;
        }

        .dashboard-auth-main {
            flex: 1;
        }
    </style>
    <?php echo $__env->yieldPushContent('after-styles'); ?>
</head>
<body>
    <div class="dashboard-auth-shell">
        <header class="dashboard-auth-header">
            <a href="<?php echo e(url('/app')); ?>" class="dashboard-auth-brand"><?php echo e(app_name()); ?></a>
        </header>

        <main class="dashboard-auth-main">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script>
        toastr.options = {
            closeButton: true,
            progressBar: true,
            positionClass: 'toast-top-center',
            timeOut: 7000,
            extendedTimeOut: 1000
        };

        window.createNotify = function ({ title = '', desc = '', type = 'info' }) {
            const message = title ? `${title}: ${desc}` : desc;
            if (typeof toastr[type] === 'function') {
                toastr[type](desc, title);
                return;
            }
            toastr.info(message);
        };

        <?php if(session('message')): ?>
            toastr.success(<?php echo json_encode(session('message'), 15, 512) ?>);
        <?php endif; ?>

        <?php if(session('success')): ?>
            toastr.success(<?php echo json_encode(session('success'), 15, 512) ?>);
        <?php endif; ?>

        <?php if(session('error')): ?>
            toastr.error(<?php echo json_encode(session('error'), 15, 512) ?>);
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                toastr.error(<?php echo json_encode($error, 15, 512) ?>);
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        if (localStorage.getItem('flash_message')) {
            toastr.success(localStorage.getItem('flash_message'));
            localStorage.removeItem('flash_message');
        }
    </script>
    <?php echo $__env->yieldPushContent('after-scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\layouts\dashboard-auth.blade.php ENDPATH**/ ?>