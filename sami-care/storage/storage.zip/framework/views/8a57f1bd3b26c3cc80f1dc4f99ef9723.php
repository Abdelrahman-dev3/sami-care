<p>
    <?php echo app('translator')->get("Displaing all the values of :module_name (Id: :id)", ['module_name'=>ucwords($module_name_singular), 'id'=>$$module_name_singular->id]); ?>.
</p>
<table class="table table-responsive table-hover table-bordered">
    <?php
    $all_columns = $$module_name_singular->getTableColumns();
    ?>
    <thead>
        <tr>
            <th scope="col">
                <strong>
                    <?php echo app('translator')->get('Name'); ?>
                </strong>
            </th>
            <th scope="col">
                <strong>
                    <?php echo app('translator')->get('Value'); ?>
                </strong>
            </th>
        </tr>
    </thead>
    <tbody>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $all_columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <strong>
                    <?php echo e(__(label_case($column->Field))); ?>

                </strong>
            </td>
            <td>
                <?php echo show_column_value($$module_name_singular, $column); ?>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </tbody>
</table>


<?php if (isset($component)) { $__componentOriginala2772d123992ff773f161a8f4fee8224 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala2772d123992ff773f161a8f4fee8224 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.library.lightbox','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('library.lightbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala2772d123992ff773f161a8f4fee8224)): ?>
<?php $attributes = $__attributesOriginala2772d123992ff773f161a8f4fee8224; ?>
<?php unset($__attributesOriginala2772d123992ff773f161a8f4fee8224); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala2772d123992ff773f161a8f4fee8224)): ?>
<?php $component = $__componentOriginala2772d123992ff773f161a8f4fee8224; ?>
<?php unset($__componentOriginala2772d123992ff773f161a8f4fee8224); ?>
<?php endif; ?>
<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\includes\show.blade.php ENDPATH**/ ?>