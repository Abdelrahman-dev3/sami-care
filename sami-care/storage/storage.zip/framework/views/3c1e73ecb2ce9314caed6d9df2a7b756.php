

<?php $__env->startSection('title'); ?>
    <?php echo e(__('messages.order_categories')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <h4 class="mb-0"><?php echo e(__('messages.order_categories')); ?></h4>
                <button id="save-order" class="btn btn-primary">
                    <i class="fa-solid fa-floppy-disk me-1"></i> <?php echo e(__('messages.save_order')); ?>

                </button>
            </div>

            <p class="text-muted mb-3"><?php echo e(__('messages.drag_to_order')); ?></p>

            <ul id="categories-sortable" class="list-group">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item d-flex align-items-center justify-content-between" data-id="<?php echo e($category->id); ?>">
                        <span class="d-flex align-items-center gap-2">
                            <i class="fa-solid fa-grip-vertical text-muted"></i>
                            <?php echo e($category->name); ?>

                        </span>
                        <span class="badge bg-light text-dark">#<?php echo e($loop->iteration); ?></span>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.2/Sortable.min.js"></script>
    <script>
        const list = document.getElementById('categories-sortable');
        const saveBtn = document.getElementById('save-order');

        const sortable = new Sortable(list, {
            animation: 150,
            handle: '.fa-grip-vertical'
        });

        saveBtn.addEventListener('click', () => {
            const ids = Array.from(list.querySelectorAll('[data-id]')).map(el => el.dataset.id);
            fetch('<?php echo e(route("backend.categories.order.update")); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                body: JSON.stringify({ ids })
            })
            .then(res => res.json())
            .then(data => {
                if (data.status) {
                    if (typeof window.successSnackbar === 'function') {
                        window.successSnackbar(data.message);
                    }
                } else {
                    if (typeof window.errorSnackbar === 'function') {
                        window.errorSnackbar(data.message);
                    } else {
                        alert(data.message || 'Error');
                    }
                }
            })
            .catch(() => {
                alert('Error');
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\Modules\Category\Resources\views\backend\categories\order.blade.php ENDPATH**/ ?>