

<?php $__env->startSection('title', __('cafe.order_details')); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('backend.cafe.partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0"><?php echo e($order->order_number); ?></h4>
                    <?php echo $order->status_label; ?>

                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table align-middle">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('cafe.item')); ?></th>
                                    <th><?php echo e(__('cafe.quantity')); ?></th>
                                    <th><?php echo e(__('cafe.price')); ?></th>
                                    <th><?php echo e(__('cafe.subtotal')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo e($item->item_name); ?></strong>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->notes): ?>
                                                <div class="small text-muted"><?php echo e($item->notes); ?></div>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </td>
                                        <td><?php echo e($item->quantity); ?></td>
                                        <td><?php echo e(number_format($item->item_price, 2)); ?></td>
                                        <td><?php echo e(number_format($item->subtotal, 2)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="3" class="text-end"><?php echo e(__('cafe.total')); ?></th>
                                    <th><?php echo e(number_format($order->total, 2)); ?></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->notes): ?>
                        <div class="alert alert-light mb-0"><?php echo e($order->notes); ?></div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header"><h5 class="mb-0"><?php echo e(__('cafe.order_info')); ?></h5></div>
                <div class="card-body">
                    <p><strong><?php echo e(__('cafe.table')); ?>:</strong> <?php echo e($order->table?->name); ?></p>
                    <p><strong><?php echo e(__('cafe.time')); ?>:</strong> <?php echo e($order->created_at?->format('Y-m-d H:i')); ?></p>
                    <p><strong><?php echo e(__('cafe.customer_name')); ?>:</strong> <?php echo e($order->customer_name ?: '-'); ?></p>
                    <p><strong><?php echo e(__('cafe.customer_phone')); ?>:</strong> <?php echo e($order->customer_phone ?: '-'); ?></p>

                    <form method="POST" action="<?php echo e(route('backend.cafe.orders.status', $order)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <label class="form-label"><?php echo e(__('cafe.change_status')); ?></label>
                        <select name="status" class="form-select mb-3">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['pending', 'preparing', 'ready', 'delivered', 'cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($status); ?>" <?php if($order->status === $status): echo 'selected'; endif; ?>><?php echo e(__('cafe.status_'.$status)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </select>
                        <button class="btn btn-primary w-100" type="submit"><?php echo e(__('cafe.update_status')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\cafe\orders\show.blade.php ENDPATH**/ ?>