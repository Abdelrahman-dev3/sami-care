

<?php $__env->startSection('title'); ?> <?php echo e(__($module_action)); ?> <?php echo e(__($module_title)); ?> <?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">

        <?php if (isset($component)) { $__componentOriginal57a22d33ea7984d606412297cfe33b67 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57a22d33ea7984d606412297cfe33b67 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.section-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.section-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <i class="<?php echo e($module_icon); ?>"></i> <?php echo e($module_title); ?> <small class="text-muted"><?php echo e(__($module_action)); ?></small>

             <?php $__env->slot('subtitle', null, []); ?> 
                <?php echo app('translator')->get(":module_name Management Dashboard", ['module_name'=>Str::title($module_name)]); ?>
             <?php $__env->endSlot(); ?>
             <?php $__env->slot('toolbar', null, []); ?> 
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add_'.$module_name)): ?>
                <?php if (isset($component)) { $__componentOriginal9b9e18b95e82fd4467419c83b8a91f29 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9b9e18b95e82fd4467419c83b8a91f29 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.create','data' => ['route' => ''.e(route("backend.notification-templates.create")).'','title' => ''.e(__('Create')).' '.e(__($module_title)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('buttons.create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => ''.e(route("backend.notification-templates.create")).'','title' => ''.e(__('Create')).' '.e(__($module_title)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9b9e18b95e82fd4467419c83b8a91f29)): ?>
<?php $attributes = $__attributesOriginal9b9e18b95e82fd4467419c83b8a91f29; ?>
<?php unset($__attributesOriginal9b9e18b95e82fd4467419c83b8a91f29); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9b9e18b95e82fd4467419c83b8a91f29)): ?>
<?php $component = $__componentOriginal9b9e18b95e82fd4467419c83b8a91f29; ?>
<?php unset($__componentOriginal9b9e18b95e82fd4467419c83b8a91f29); ?>
<?php endif; ?>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('restore_'.$module_name)): ?>
                <div class="btn-group">
                    <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" data-bs-target="#module-dropdown-01" aria-expanded="false">
                        <i class="fas fa-cog"></i>
                    </button>
                    <ul class="dropdown-menu" id="module-dropdown-01">
                        <li>
                            <a class="dropdown-item" href='<?php echo e(route("backend.notification-templates.trashed")); ?>'>
                                <i class="fas fa-eye-slash"></i> View trash
                            </a>
                        </li>
                    </ul>
                </div>
                <?php endif; ?>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57a22d33ea7984d606412297cfe33b67)): ?>
<?php $attributes = $__attributesOriginal57a22d33ea7984d606412297cfe33b67; ?>
<?php unset($__attributesOriginal57a22d33ea7984d606412297cfe33b67); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57a22d33ea7984d606412297cfe33b67)): ?>
<?php $component = $__componentOriginal57a22d33ea7984d606412297cfe33b67; ?>
<?php unset($__componentOriginal57a22d33ea7984d606412297cfe33b67); ?>
<?php endif; ?>
        <div class="row mt-4">
          <div class="col">
              <table id="datatable" class="table table-bordered table-hover table-responsive">
                  <tbody>
                      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $$module_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module_name_singular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          <td>
                              <?php echo e($module_name_singular->id); ?>

                          </td>
                          <td>
                              <a href="<?php echo e(url("app/$module_name", $module_name_singular->id)); ?>"><?php echo e($module_name_singular->name); ?></a>
                          </td>
                          <td>
                              <?php echo e($module_name_singular->updated_at->diffForHumans()); ?>

                          </td>
                          <td>
                              <?php echo e($module_name_singular->created_by); ?>

                          </td>
                          <td class="text-end">
                              <a href='<?php echo route("backend.$module_name.edit", $module_name_singular); ?>' class='btn btn-sm btn-primary mt-1' data-bs-toggle="tooltip" title="Edit <?php echo e(__($module_title)); ?>"><i class="fas fa-wrench"></i></a>
                              <a href='<?php echo route("backend.$module_name.show", $module_name_singular); ?>' class='btn btn-sm btn-success mt-1' data-bs-toggle="tooltip" title="Show <?php echo e(__($module_title)); ?>"><i class="fas fa-tv"></i></a>
                          </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                  </tbody>
              </table>
          </div>
      </div>
  </div>
  <div class="card-footer">
      <div class="row">
          <div class="col-7">
              <div class="float-left">
                  Total <?php echo e($$module_name->total()); ?> <?php echo e(__($module_name)); ?>

              </div>
          </div>
          <div class="col-5">
              <div class="float-end">
                  <?php echo $$module_name->render(); ?>

              </div>
          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\Modules\NotificationTemplate\Resources\views\backend\notificationtemplates\index.blade.php ENDPATH**/ ?>