<p class="m-0"><?php echo e($serviceName); ?></p>
<p class="m-0 fs-6"><strong><?php echo e($customerName); ?></strong></p>
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($branchName)): ?>
    <p class="m-0 fs-6"><?php echo e($branchName); ?></p>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($createdByName)): ?>
    <p class="m-0 fs-6">حجز بواسطة: <?php echo e($createdByName); ?></p>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\Modules\Booking\Resources\views\backend\bookings\calender\event.blade.php ENDPATH**/ ?>