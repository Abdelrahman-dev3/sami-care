

<?php $__env->startSection('title'); ?>
<?php echo e(__($module_action)); ?> <?php echo e(__($module_title)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <div class="header-title">
                    <h4 class="card-title mb-0">Permission & Role</h4>
                </div>
                <div>
                    <?php if (isset($component)) { $__componentOriginal57a22d33ea7984d606412297cfe33b67 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57a22d33ea7984d606412297cfe33b67 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.section-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.section-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <div>

                        </div>
                         <?php $__env->slot('toolbar', null, []); ?> 


                            <div class="input-group flex-nowrap">
                            </div>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Auth::user()->can('add_page')): ?>
                            <?php if (isset($component)) { $__componentOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.offcanvas','data' => ['target' => '#form-offcanvas','title' => ''.e(__('messages.create')).'  '.e(__('page.lbl_role')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('buttons.offcanvas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['target' => '#form-offcanvas','title' => ''.e(__('messages.create')).'  '.e(__('page.lbl_role')).'']); ?><?php echo e(__('messages.create')); ?> 
                                <?php echo e(__('page.lbl_role')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8)): ?>
<?php $attributes = $__attributesOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8; ?>
<?php unset($__attributesOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8)): ?>
<?php $component = $__componentOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8; ?>
<?php unset($__componentOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8); ?>
<?php endif; ?>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                         <?php $__env->endSlot(); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57a22d33ea7984d606412297cfe33b67)): ?>
<?php $attributes = $__attributesOriginal57a22d33ea7984d606412297cfe33b67; ?>
<?php unset($__attributesOriginal57a22d33ea7984d606412297cfe33b67); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57a22d33ea7984d606412297cfe33b67)): ?>
<?php $component = $__componentOriginal57a22d33ea7984d606412297cfe33b67; ?>
<?php unset($__componentOriginal57a22d33ea7984d606412297cfe33b67); ?>
<?php endif; ?>


                </div>
            </div>
            <div class="card-body">

                <div class="accordion accordion-flush" id="accordionFlushExample">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($role->name !== 'admin' ): ?>
                    <?php echo e(Form::open(['route' => ['backend.permission-role.store', $role->id],'method' => 'post'])); ?>

                    <div class="accordion-item" id="permission_<?php echo e($role->id); ?>">
                        <h2 class="accordion-header d-flex" id="flush-headingOne">
                            <button class="accordion-button collapsed " type="button" data-bs-toggle="collapse"
                                data-bs-target="#flush-collapseOne_<?php echo e($role->id); ?>" aria-expanded="false"
                                aria-controls="flush-collapseOne">
                                <h5><?php echo e(ucfirst($role->title)); ?></h5>
                            </button>

                        </h2>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($role->is_fixed ==0): ?>
                        <a class="btn btn-soft-danger btn-sm" onclick="delete_role(<?php echo e($role->id); ?>)"
                            data-bs-toggle="tooltip" title="<?php echo e(__('messages.delete')); ?>"> <i class="fa-solid fa-trash"></i>
                            Delete</a>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <a class="btn btn-soft-info btn-sm" onclick="reset_permission(<?php echo e($role->id); ?>)"
                            data-bs-toggle="tooltip" title="<?php echo e(__('Reset Permission')); ?>"> <i class="fas fa-undo"></i>
                            Reset</a>
                        <div id="flush-collapseOne_<?php echo e($role->id); ?>" class="accordion-collapse collapse"
                            aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">

                            <div class="container">
                                <div class="row m-3 py-3 heading">
                                    <div class="col-sm">
                                        <h6>Modules</h6>
                                    </div>
                                    <div class="col-sm">
                                        <h6>View</h6>
                                    </div>
                                    <div class="col-sm">
                                        <h6>Add</h6>
                                    </div>
                                    <div class="col-sm">
                                        <h6>Edit</h6>
                                    </div>
                                    <div class="col-sm">
                                        <h6>Delete</h6>
                                    </div>
                                    <div class="col-sm">
                                        <?php echo e(Form::submit( __('messages.save'), ['class'=>'btn btn-md btn-primary'])); ?>

                                    </div>
                                </div>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row  m-3   align-items-center permission_data">
                                    <div class="col-md-2">
                                        <span><?php echo e(ucwords($module->module_name)); ?></span>
                                    </div>
                                    <div class="col-md-2">
                                        <span><input type="checkbox"
                                                id="role-<?php echo e($role->name); ?>-permission-view_<?php echo e(strtolower(str_replace(' ', '_', $module->module_name))); ?>"
                                                name="permission[view_<?php echo e(strtolower(str_replace(' ', '_', $module->module_name))); ?>][]"
                                                value="<?php echo e($role->name); ?>" class="form-check-input"
                                                <?php echo e((AuthHelper::checkRolePermission($role, 'view_'.strtolower(str_replace(' ', '_', $module->module_name)))) ? 'checked' : ''); ?>></span>
                                    </div>
                                    <div class="col-md-2">
                                        <span><input type="checkbox"
                                                id="role-<?php echo e($role->name); ?>-permission-add_<?php echo e(strtolower(str_replace(' ', '_', $module->module_name))); ?>"
                                                name="permission[add_<?php echo e(strtolower(str_replace(' ', '_', $module->module_name))); ?>][]"
                                                value="<?php echo e($role->name); ?>" class="form-check-input"
                                                <?php echo e((AuthHelper::checkRolePermission($role, 'add_'.strtolower(str_replace(' ', '_', $module->module_name)))) ? 'checked' : ''); ?>></span>
                                    </div>
                                    <div class="col-md-2">
                                        <span><input type="checkbox"
                                                id="role-<?php echo e($role->name); ?>-permission-edit_<?php echo e(strtolower(str_replace(' ', '_', $module->module_name))); ?>"
                                                name="permission[edit_<?php echo e(strtolower(str_replace(' ', '_', $module->module_name))); ?>][]"
                                                value="<?php echo e($role->name); ?>" class="form-check-input"
                                                <?php echo e((AuthHelper::checkRolePermission($role, 'edit_'.strtolower(str_replace(' ', '_', str_replace(' ', '_', $module->module_name))))) ? 'checked' : ''); ?>></span>
                                    </div>
                                    <div class="col-md-2">
                                        <span><input type="checkbox"
                                                id="role-<?php echo e($role->name); ?>-permission-delete_<?php echo e(strtolower(str_replace(' ', '_', $module->module_name))); ?>"
                                                name="permission[delete_<?php echo e(strtolower(str_replace(' ', '_', $module->module_name))); ?>][]"
                                                value="<?php echo e($role->name); ?>" class="form-check-input"
                                                <?php echo e((AuthHelper::checkRolePermission($role, 'delete_'.strtolower(str_replace(' ', '_', $module->module_name)))) ? 'checked' : ''); ?>></span>
                                    </div>

                                    <?php
                                    $decodedData = json_decode($module->more_permission,true);
                                    ?>

                                    <div class="col-md-2 more_field">
                                        <button class="accordion-button <?php echo e($decodedData != '' ? '' : 'accordion_btn'); ?>"
                                            type="button" data-bs-toggle="collapse"
                                            data-bs-target="#collapseOne_<?php echo e($module->id); ?>"
                                            aria-expanded="<?php echo e($decodedData != '' ? 'true' : 'false'); ?>"
                                            aria-controls="collapseOne">
                                            <?php echo e($decodedData != '' ? 'More' : '-'); ?>

                                        </button>
                                    </div>

                                    <div id="collapseOne_<?php echo e($module->id); ?>" class="accordion-collapse collapse "
                                        aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($decodedData !=''): ?>

                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $decodedData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <div class="heading  py-3">


                                                <div class="row  m-3   align-items-center  ">
                                                    <div class="col-md-3">
                                                        <span><?php echo e(ucwords($module->module_name)); ?>

                                                            <?php echo e(ucwords(str_replace('_', ' ', $permission_data))); ?></span>
                                                    </div>
                                                    <div class="col-md-2">

                                                        <span><input type="checkbox"
                                                                id="role-<?php echo e($role->name); ?>-permission-<?php echo e(strtolower(str_replace(' ', '_', $module->module_name))); ?>_<?php echo e(strtolower(str_replace(' ', '_', $permission_data))); ?>"
                                                                name="permission[<?php echo e(strtolower(str_replace(' ', '_', $module->module_name))); ?>_<?php echo e(strtolower(str_replace(' ', '_', $permission_data))); ?>][]"
                                                                value="<?php echo e($role->name); ?>" class="form-check-input"
                                                                <?php echo e((AuthHelper::checkRolePermission($role, strtolower(str_replace(' ', '_', $module->module_name).'_'.strtolower(str_replace(' ', '_', $permission_data))))) ? 'checked' : ''); ?>></span>
                                                    </div>



                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            </div>
                        </div>
                    </div>

                    <?php echo e(Form::close()); ?>


                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                </div>

             


            </div>
        </div>

        <div data-render="app">
    <manage-role-form create-title="<?php echo e(__('messages.create')); ?>  <?php echo e(__('page.lbl_role')); ?>">
    </manage-role-form>

</div>

    </div>
</div>



<script>

function reset_permission(role_id) {

    var url = "/app/permission-role/reset/" + role_id;

    $.ajax({
        url: url,
        type: 'GET',
        dataType: 'json',
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(response) {

            successSnackbar(response.message);
        },
        error: function(response) {
            alert('error');
        }
    });
}



function delete_role(role_id) {
    var url = "<?php echo e(route('backend.role.destroy', ['role' => ':role_id'])); ?>";
    url = url.replace(':role_id', role_id);

    $.ajax({
        url: url,
        type: 'DELETE',
        dataType: 'json',
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(response) {
            $('#permission_' + role_id).hide();
            successSnackbar(response.message);
        },
        error: function(response) {
            alert('error');
        }
    });
}


</script>



<?php $__env->startPush('after-scripts'); ?>
<script src="<?php echo e(mix('js/vue.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/form-offcanvas/index.js')); ?>" defer></script>

<?php $__env->stopPush(); ?>

<style>
.heading {
    background-color: #c3c3c330;
}

.heading h6 {
    color: #898688 !important;
}

.permission_data {

    border-bottom: 1px solid;
    border-bottom-color: #80808014;

}

.accordion_btn {

    background-color: transparent !important;

}

.accordion_btn::after {

    height: 0 !important;
}

h2#flush-headingOne {
    width: 98% !important;
}
</style>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\permission-role\test.blade.php ENDPATH**/ ?>