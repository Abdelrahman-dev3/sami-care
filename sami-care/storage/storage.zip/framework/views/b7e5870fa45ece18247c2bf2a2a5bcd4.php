<li class="breadcrumb-item"><a href="<?php echo e(route('backend.dashboard')); ?>"><i class="fa-solid fa-gauge-high"></i> <?php echo e('Dashboard'); ?></a></li>

<?php echo $slot; ?>

<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\components\backend-breadcrumbs.blade.php ENDPATH**/ ?>