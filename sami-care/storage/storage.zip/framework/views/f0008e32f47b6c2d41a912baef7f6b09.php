

<?php $__env->startSection('content'); ?>
    <h1>Hello World</h1>

    <p>Module: <?php echo config('affiliate.name'); ?></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('affiliate::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\Modules\Affiliate\Resources\views\index.blade.php ENDPATH**/ ?>