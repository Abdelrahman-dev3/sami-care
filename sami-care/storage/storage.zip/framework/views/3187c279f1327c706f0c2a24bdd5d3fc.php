<?php echo csrf_field(); ?>

<div class="row g-3">
    <div class="col-md-8">
        <label class="form-label"><?php echo e(__('blog.title_field')); ?></label>
        <input type="text" name="title" class="form-control" value="<?php echo e(old('title', $blog->title ?? '')); ?>" required>
    </div>

    <div class="col-md-4">
        <label class="form-label"><?php echo e(__('blog.published_at')); ?></label>
        <input type="datetime-local" name="published_at" class="form-control" value="<?php echo e(old('published_at', isset($blog) && $blog->published_at ? $blog->published_at->format('Y-m-d\TH:i') : '')); ?>">
    </div>

    <div class="col-md-8">
        <label class="form-label"><?php echo e(__('blog.image')); ?></label>
        <input type="file" name="image" class="form-control" accept="image/*">
    </div>

    <div class="col-md-4">
        <label class="form-label d-block"><?php echo e(__('blog.status')); ?></label>
        <div class="form-check form-switch mt-2">
            <input type="checkbox" name="status" value="1" class="form-check-input" id="blog-status" <?php if(old('status', $blog->status ?? true)): echo 'checked'; endif; ?>>
            <label class="form-check-label" for="blog-status"><?php echo e(__('blog.active')); ?></label>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($blog)): ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($blog->image): ?>
            <div class="col-md-3">
                <img src="<?php echo e($blog->image_url); ?>" alt="<?php echo e($blog->title); ?>" class="rounded" style="width: 120px; height: 120px; object-fit: cover;">
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="col-12">
        <label class="form-label"><?php echo e(__('blog.excerpt')); ?></label>
        <textarea name="excerpt" class="form-control" rows="3" maxlength="500"><?php echo e(old('excerpt', $blog->excerpt ?? '')); ?></textarea>
    </div>

    <div class="col-12">
        <label class="form-label"><?php echo e(__('blog.content')); ?></label>
        <textarea name="content" class="form-control" rows="12" required><?php echo e(old('content', $blog->content ?? '')); ?></textarea>
    </div>

    <div class="col-12 d-flex gap-2">
        <button class="btn btn-primary" type="submit"><?php echo e(__('blog.save')); ?></button>
        <a class="btn btn-light" href="<?php echo e(route('backend.blogs.index')); ?>"><?php echo e(__('blog.cancel')); ?></a>
    </div>
</div>
<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\blogs\form.blade.php ENDPATH**/ ?>