<?php
    $route = 'permission.store';
    $method = 'post';
    if(isset($data->id)) {
        $route = ['backend.permission.update', $data->id];
        $method = 'put';
    }
?>

<?php echo e(Form::model($data,['route' => $route])); ?>

    <?php echo method_field($method); ?>
    <div class="form-group">
        <label class="form-label"><?php echo e(trans('permission-role.permission_label_title')); ?> <span class="text-danger">*</span></label>
        <?php echo e(Form::text('title', old('title'), ['class' => 'form-control','id' => 'permission-title', 'placeholder' => 'Permission Title', 'required'])); ?>

    </div>
    <?php echo e(Form::submit( __('messages.save'), ['class'=>'btn btn-primary'])); ?>

    <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo e(__('messages.close')); ?></button>
<?php echo e(Form::close()); ?>

<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\permission-role\form-permission.blade.php ENDPATH**/ ?>