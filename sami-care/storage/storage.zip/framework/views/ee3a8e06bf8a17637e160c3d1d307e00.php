

<?php $__env->startSection('title', __('blog.add_blog')); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('backend.blogs.partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <div class="card-header">
            <h4 class="mb-0"><?php echo e(__('blog.add_blog')); ?></h4>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('backend.blogs.store')); ?>" enctype="multipart/form-data">
                <?php echo $__env->make('backend.blogs.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\blogs\create.blade.php ENDPATH**/ ?>