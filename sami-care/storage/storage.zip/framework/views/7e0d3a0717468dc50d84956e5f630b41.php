

<?php $__env->startSection('title', __('cafe.categories')); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('backend.cafe.partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h4 class="mb-0"><?php echo e(__('cafe.categories')); ?></h4>
            <a href="<?php echo e(route('backend.cafe.categories.create')); ?>" class="btn btn-primary">
                <i class="fa-solid fa-plus"></i> <?php echo e(__('cafe.add_category')); ?>

            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead>
                        <tr>
                            <th><?php echo e(__('cafe.name')); ?></th>
                            <th><?php echo e(__('cafe.items_count')); ?></th>
                            <th><?php echo e(__('cafe.status')); ?></th>
                            <th><?php echo e(__('cafe.sort_order')); ?></th>
                            <th class="text-end"><?php echo e(__('cafe.actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <strong><?php echo e($category->name); ?></strong>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($category->description): ?>
                                        <div class="text-muted small"><?php echo e(\Illuminate\Support\Str::limit($category->description, 80)); ?></div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td><?php echo e($category->items_count); ?></td>
                                <td>
                                    <span class="badge <?php echo e($category->status ? 'bg-success' : 'bg-secondary'); ?>">
                                        <?php echo e($category->status ? __('cafe.active') : __('cafe.inactive')); ?>

                                    </span>
                                </td>
                                <td><?php echo e($category->sort_order); ?></td>
                                <td class="text-end">
                                    <a class="btn btn-sm btn-soft-primary" href="<?php echo e(route('backend.cafe.categories.edit', $category)); ?>">
                                        <i class="fa-solid fa-pen"></i>
                                    </a>
                                    <form class="d-inline" method="POST" action="<?php echo e(route('backend.cafe.categories.destroy', $category)); ?>" onsubmit="return confirm('<?php echo e(__('cafe.confirm_delete')); ?>')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-soft-danger" type="submit"><i class="fa-solid fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="5" class="text-center text-muted"><?php echo e(__('cafe.no_records')); ?></td></tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($categories->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\cafe\categories\index.blade.php ENDPATH**/ ?>