<a <?php echo e($attributes->merge(['class' => 'btn'])); ?>>
    <?php echo e($slot); ?>

</a>
<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\components\button-a.blade.php ENDPATH**/ ?>