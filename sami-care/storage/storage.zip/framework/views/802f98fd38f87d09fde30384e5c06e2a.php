<form action="<?php echo e($url ?? ''); ?>" id="quick-action-form" class="form-disabled d-flex gap-3 align-items-stretch flex-md-row flex-column">
  <?php echo csrf_field(); ?>
  <?php echo e($slot); ?>

  <input type="hidden" name="message_change-is_featured" value="Are you sure you want to perform this action?">
  <input type="hidden" name="message_change-status" value="Are you sure you want to perform this action?">
  <input type="hidden" name="message_delete" value="Are you sure you want to delete it?">
  <button class="btn btn-gray" id="quick-action-apply"><?php echo e(__('messages.apply')); ?></button>
</form>
<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\components\backend\quick-action.blade.php ENDPATH**/ ?>