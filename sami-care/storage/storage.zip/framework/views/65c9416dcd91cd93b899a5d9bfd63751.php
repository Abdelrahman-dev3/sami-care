<?php echo csrf_field(); ?>
<div class="row g-3">
    <div class="col-md-8">
        <label class="form-label"><?php echo e(__('cafe.table_name')); ?></label>
        <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $table->name ?? '')); ?>" required>
    </div>
    <div class="col-md-4 d-flex align-items-end">
        <div class="form-check form-switch mb-2">
            <input type="hidden" name="status" value="0">
            <input class="form-check-input" type="checkbox" name="status" value="1" id="status" <?php if(old('status', $table->status ?? true)): echo 'checked'; endif; ?>>
            <label class="form-check-label" for="status"><?php echo e(__('cafe.active')); ?></label>
        </div>
    </div>
    <div class="col-12 d-flex gap-2">
        <button class="btn btn-primary" type="submit"><?php echo e(__('cafe.save')); ?></button>
        <a class="btn btn-light" href="<?php echo e(route('backend.cafe.tables.index')); ?>"><?php echo e(__('cafe.cancel')); ?></a>
    </div>
</div>
<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\cafe\tables\form.blade.php ENDPATH**/ ?>