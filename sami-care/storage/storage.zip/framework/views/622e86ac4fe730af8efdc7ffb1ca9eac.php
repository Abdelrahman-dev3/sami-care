

<?php $__env->startSection('title', __('cafe.edit_table')); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('backend.cafe.partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <div class="card-header"><h4 class="mb-0"><?php echo e(__('cafe.edit_table')); ?></h4></div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('backend.cafe.tables.update', $table)); ?>">
                <?php echo method_field('PUT'); ?>
                <?php echo $__env->make('backend.cafe.tables.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
            <div class="mt-4 p-3 bg-light rounded">
                <img src="<?php echo e($table->qr_url); ?>" alt="<?php echo e($table->name); ?>" style="width: 160px; height: 160px;">
                <div class="mt-2"><a href="<?php echo e($table->order_url); ?>" target="_blank"><?php echo e($table->order_url); ?></a></div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\cafe\tables\edit.blade.php ENDPATH**/ ?>