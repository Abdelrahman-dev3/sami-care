

<div class="iq-navbar-header navs-bg-color" style="height: 120px;">
    <div class="container-fluid iq-container">
        <div class="row">
            <div class="col-md-12">
                <div class="d-flex justify-content-between align-items-center flex-wrap">
                    <div class="px-4">
                        <h2><?php echo e(__($module_title ?? '')); ?></h2>
                    </div>
                    <div>
                      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!isset($global_booking)): ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Auth::user()->can('add_booking')): ?>
                        <a href="javascript:void(0)" class="btn btn-secondary" id="appointment-button"><i class="fa-solid fa-plus"></i> <?php echo e(__('messages.appointment')); ?></a>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                      <?php echo $__env->yieldContent('banner-button'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="iq-header-img">
    </div>
</div>
<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\components\partials\sub-header.blade.php ENDPATH**/ ?>