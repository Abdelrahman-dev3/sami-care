<?php
$required = (Str::contains($field['rules'], 'required')) ? "required" : "";
$required_mark = ($required != "") ? '<span class="text-danger"> <strong>*</strong> </span>' : '';
?>

<div class="form-group mb-3 col-md-6 <?php echo e($errors->has($field['name']) ? ' has-error' : ''); ?>">
    <label for="<?php echo e($field['name']); ?>" class='form-label'> <strong><?php echo e($field['label']); ?></strong> (<?php echo e($field['name']); ?>)</label> <?php echo $required_mark; ?>

    <div class="row">
        <div class="col-lg-8 order-1">
            <input type="<?php echo e($field['type']); ?>"
                name="<?php echo e($field['name']); ?>"
                value="<?php echo e(old($field['name'], setting($field['name']))); ?>"
                class="form-control <?php echo e(Arr::get( $field, 'class')); ?> <?php echo e($errors->has($field['name']) ? ' is-invalid' : ''); ?>"
                id="<?php echo e($field['name']); ?>"
                placeholder="<?php echo e($field['label']); ?>" <?php echo e($required); ?>>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->has($field['name'])): ?> <small class="invalid-feedback"><?php echo e($errors->first($field['name'])); ?></small> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
        <div class="col-lg-4 order-0">
            <div class="card text-center inline-block">
                <div class="card-body <?php echo e(isset($field['imageClass']) ? $field['imageClass'] : ''); ?>">
                    <img class="img-fluid" src="<?php echo e(asset(setting($field['name']) )); ?>" alt="<?php echo e($field['name']); ?>">
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\resources\views\backend\settings\fields\file.blade.php ENDPATH**/ ?>