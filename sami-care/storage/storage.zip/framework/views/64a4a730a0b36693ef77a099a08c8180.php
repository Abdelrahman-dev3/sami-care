<div class="row mb-3">
    <div class="col-12 col-sm-4">
        <div class="form-group">
            <?php
            $field_name = 'name';
            $field_lable = label_case($field_name);
            $field_placeholder = $field_lable;
            $required = "required";
            ?>
            <?php echo e(html()->label($field_lable, $field_name)->class('form-label')); ?> <?php echo fielf_required($required); ?>

            <?php echo e(html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"])); ?>

        </div>
    </div>
</div>

<?php /**PATH C:\xampp_8\htdocs\sami-care\sami-care\Modules\Currency\Resources\views\backend\currencies\form.blade.php ENDPATH**/ ?>