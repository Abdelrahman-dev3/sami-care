<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Term extends Model
{
    use HasFactory;
    protected $fillable = ['title' , 'points' , 'parent_id'];
    protected $casts = [
        'title' => 'array',
        'points' => 'array',
    ];

}
