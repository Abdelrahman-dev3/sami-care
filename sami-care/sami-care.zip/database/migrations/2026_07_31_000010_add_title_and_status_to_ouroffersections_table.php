<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('ouroffersections', function (Blueprint $table) {
            $table->json('title')->nullable()->after('id');
            $table->boolean('status')->default(1)->after('overlay');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('ouroffersections', function (Blueprint $table) {
            $table->dropColumn(['title', 'status']);
        });
    }
};
